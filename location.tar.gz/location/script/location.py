#!/usr/bin/env python
#-- coding:UTF-8 --
import rospy

import getlocationfront
import getlocationrear
from std_msgs.msg import Float32MultiArray
import time

def publisher():

    pubf = rospy.Publisher("locationfront" , Float32MultiArray , queue_size = 1)
    pubr = rospy.Publisher("locationrear" , Float32MultiArray , queue_size = 1)
    rospy.init_node('talker' , anonymous = True)
    rate = rospy.Rate(10)

    while not rospy.is_shutdown():
        locationfx , locationfy = getlocationfront.main()
        locationrx , locationry = getlocationrear.main()
        locationf = [locationfx , locationfy]
        locationr = [locationrx , locationry]
        #locationf = [1,1]
        #locationr = [2,2]
        arrayf = Float32MultiArray(data = locationf)
        arrayr = Float32MultiArray(data = locationr)
        pubf.publish(arrayf)
        pubr.publish(arrayr)
        rate.sleep()

if __name__ == '__main__':
    try:
        publisher()
    except rospy.ROSInterruptException:
        pass
