#!/usr/bin/env python
#-- coding:UTF-8 --
import serial
import time
import numpy
import binascii

def GetDistance():
    NUM = 6
    port = serial.Serial('/dev/ttyUSB1', 115200)
    DISTANCE = [0]*NUM
    head1 = port.read(1)
    head1 = binascii.b2a_hex(head1)
    # print(head1)
    if head1 == '55':
        head2 = binascii.b2a_hex(port.read(1))
        if head2 == 'aa':
            data = binascii.b2a_hex(port.read(19))
            BaseStationID0L = int(data[10:12] , 16)
            BaseStationID0H = int(data[12:14] , 16)
            BaseStationID0 = (BaseStationID0H<<8) + BaseStationID0L
            # print('baseid',BaseStation0)
            if BaseStationID0 == 0:
                dis0 = int(data[14:16],16)
                dis1 = int(data[16:18],16)
                dis2 = int(data[18:20],16)
                dis3 = int(data[20:22],16)
                Distance0 = (dis3 << 24) + (dis2 << 16) + (dis1 << 8) + dis0
                #print(BaseStationID0 , Distance0)
                DISTANCE[BaseStationID0] = Distance0
                num = NUM -1
                while num:
                    data1 = binascii.b2a_hex(port.read(21))
                    # print(data1)
                    BaseStationIDL = int(data1[14:16] , 16)
                    BaseStationIDH = int(data1[16:18] , 16)
                    BaseStationID1 = (BaseStationIDH<<8) + BaseStationIDL
                    dis0 = int(data1[18:20], 16)
                    dis1 = int(data1[20:22], 16)
                    dis2 = int(data1[22:24], 16)
                    dis3 = int(data1[24:26], 16)
                    Distance = (dis3 << 24) + (dis2 << 16) + (dis1 << 8) + dis0
                    #print(BaseStationID1 , Distance)
                    DISTANCE[BaseStationID1] = Distance
                    num = num - 1

                #print('distance:', DISTANCE)
		for dis in DISTANCE:
		    if dis == 0:
			DISTANCE = []
		#print('distance:' , DISTANCE)
                return DISTANCE

def Location(distance):

    dis = numpy.array(distance)
    num = numpy.argsort(dis)
    #print(num)
    ID1 = num[0]
    ID2 = num[1]
    ID3 = num[2]

    ID = numpy.array([ID1 ,ID2 , ID3])
    ID = numpy.sort(ID)

    x = [0, 2400, 2400, 4800, 4800, 6090]
    y = [0, 0,    1200, 0,    1200, 1200]

    DistanceA = distance[ID[0]]
    DistanceB = distance[ID[1]]
    DistanceC = distance[ID[2]]
    #print('ID:' , ID1,ID2,ID3)
    #print('distance:' , DistanceA , DistanceB , DistanceC)
    x1 , y1 = x[ID[0]] , y[ID[0]]
    x2 , y2 = x[ID[1]] , y[ID[1]]
    x3 , y3 = x[ID[2]] , y[ID[2]]

    Mitrax_a = numpy.array(
        [[2 * (x1 - x2), 2 * (y1 - y2)],
         [2 * (x1 - x3), 2 * (y1 - y3)]
         ])


    u1 = DistanceB ** 2 - DistanceA ** 2 - x2 ** 2 + x1 ** 2 - y2 ** 2 + y1 ** 2
    u2 = DistanceC ** 2 - DistanceA ** 2 - x3 ** 2 + x1 ** 2 - y3 ** 2 + y1 ** 2

    Mitrax_b = numpy.array([[u1], [u2]])
    X0 = Mitrax_a.T
    X1 = (X0*Mitrax_a)
    X1 = numpy.linalg.inv(X1)
    X = X1 * X0 * Mitrax_b
    x1 = (numpy.matrix(Mitrax_a)).I*Mitrax_b
    Location_x = x1[0,0]/100
    Location_y = x1[1,0]/100
    return Location_x , Location_y

def main():
    distance = Getdistance()
    x, y = Location(distance)
    
    return x, y
