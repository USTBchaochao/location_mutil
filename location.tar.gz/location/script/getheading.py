#!/usr/bin/env python
#-- coding:UTF-8 --

import math

def headingstate(x1, y1, x2,y2):
    ##位置计算（暂定）1为前车体2为后车体
    x = (x1 + x2) / 2
    y = (y1 + y2) / 2
    ##连线航向角
    dx = x1 - x2
    dy = y1 - y2
    line = math.sqrt(dx ** 2 + dy ** 2)
    if y1 > y2:
        flagheading = 1
        heading = math.atan(dx / dy)  # 标签连线航向角，前向x轴，横向y轴
    elif y2 > y1:
        flagheading = 2
        heading = math.atan(dx / dy)  # 标签连线航向角，前向x轴，横向y轴
    elif y1 == y2:
        flagheading = 0
        heading = math.pi/2
    else:
        flagheading = None
        print("Flagheading Error",x1,y1,x2,y2)
    return flagheading , heading , line

def turningstate(gamma):
    if gamma == 90:
        flagturn = 0
    elif gamma > 90:##右侧
        angle = ( 270 - gamma ) * math.pi / 180###钝角三角形的钝角，不是铰接角
        flagturn = 2
    elif gamma<90:##左侧
        angle = (gamma + 90) * math.pi / 180
        flagturn = 1
    else:
        flagturn = None
        print("Flagturn Error" , gamma)
    # print(angle*180/math.pi , flagturn)
    GAMMA = (gamma - 90) * math.pi / 180  ##铰接角，正前方为0 ，左负右正
    return angle , GAMMA , flagturn

def getheadingr(flag1 , heading , flag2 , angle , line):
    ###flag1标签连线flag， flag2铰接角flag
    lf , lr= 1 , 1
    headingr = -360
    angler = math.asin(lf*math.sin(angle)/line)
    if flag1 == 1 and flag2 == 1:
        headingr = heading + angler - math.pi/2
    elif flag1 == 2 and flag2 == 1:
        headingr = math.pi/2 - (heading - angler)
    elif flag1 == 1 and flag2 == 2:
        headingr = heading - angler -math.pi/2
    elif flag1 == 2 and flag2 == 2:
        headingr = math.pi/2 - heading - angler
    else:
        print("Flag Combation Error", flag1 , flag2)
    print(angler , heading, headingr)
    return headingr

def getheadingf(headingr , gamma):

    headingf = headingr + gamma
    return headingf

def main(x1, y1, x2, y2, gamma):
    flag1 , heading , line = headingstate(x1, y1, x2, y2)
    angle , gamma , flag2= turningstate(gamma)
    headingr = getheadingr(flag1 , heading , flag2 , angle , line)
    headingf = getheadingf(headingr , gamma)
    print(headingf , headingr)
    return headingf , headingr

# if __name__ == "__main__":
#     main(0,0,math.sqrt(2.4),math.sqrt(0.6),150)
