#!/usr/bin/env python
#-- coding:UTF-8 --
import rospy

from std_msgs.msg import Float32MultiArray
from location.msg import Frame_read
from location.msg import state
import time
import getheading

def getlocationfront():
	
	subf = rospy.wait_for_message("locationfront", Float32MultiArray)
	x = subf.data[0]
	y = subf.data[1]
	
	return x,y

def getlocationrear():

    subr = rospy.wait_for_message("locationrear", Float32MultiArray)
    x = subr.data[0]
    y = subr.data[1]
	
    return x,y

def getgamma():
	
	subgamma = rospy.wait_for_message("plc", Frame_read)
	gamma = subgamma.data[0] + subgamma.data[1]/100

	return gamma 
	
def listener():

    rospy.init_node('talker', anonymous=True)
    publocation = rospy.Publisher('location', state , queue_size = 1)
    pubheading = rospy.Publisher('heading', Float32MultiArray , queue_size = 1)
    msg = state()
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        x1, y1 = getlocationfront()
        x2, y2 = getlocationrear()
        gamma = getgamma()
        #heading = [0,0]
        headingf, headingr = getheading.main(x1, y1, x2, y2, 180)
        heading[0] = headingf
        heading[1] = headingr
        array = Float32MultiArray(data = heading)
        pubheading.publish(array)
        msg.x1 = x1
        msg.y1 = y1
        msg.x2 = x2
        msg.y2 = y2
        msg.gamma = gamma
        publocation.publish(msg)
        rate.sleep()
    #rospy.spin()


if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
